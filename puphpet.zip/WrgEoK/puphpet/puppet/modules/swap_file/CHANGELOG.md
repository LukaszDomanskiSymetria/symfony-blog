## Change Log

### upcoming (2014/02/27 11:12 +00:00)
- [c8cf711](https://github.com/petems/puppet-swap_file/commit/c8cf711bb10f100c0b9ad66a16e7e54a54f776d3) Initial Commit (@petems)
- [02e1a1a](https://github.com/petems/puppet-swap_file/commit/02e1a1ab01886028bf79e7bc870df110a53cf5b7) Rename spec file (@petems)
- [fbaa2e4](https://github.com/petems/puppet-swap_file/commit/fbaa2e46f632142f4dc63c4928c8e9e206920a2c) Update changelog with `github-changes` (@petems)
- [3952796](https://github.com/petems/puppet-swap_file/commit/39527966fac72219a1b938af38b8f3a71e3e428e) Removed old CHANGELOG (@petems)
- [43da89d](https://github.com/petems/puppet-swap_file/commit/43da89d4e4d49b4a08c16d6fa2a38774f59910fc) Update module file with details (@petems)
- [e79df44](https://github.com/petems/puppet-swap_file/commit/e79df44578f4bf1b70168bd8fa9cb3a9620463a0) Removing custom fact for memory size in bytes (@petems)
- [c267e95](https://github.com/petems/puppet-swap_file/commit/c267e959720e1cdb8573a4c44be0e0db2a48d411) Update README (@petems)
- [88095a5](https://github.com/petems/puppet-swap_file/commit/88095a5f9cebdb5499e57dab01fa208f4341d9f9) Change just windows to fail... (@petems)
- [b61645c](https://github.com/petems/puppet-swap_file/commit/b61645c00d8761a0d07ecc0da8a5ffe4bb4bdab7) Fix double quoted string lint issue (@petems)
- [#1](https://github.com/petems/puppet-swap_file/pull/1) Merge pull request #1 from petems/remove_custom_fact (@petems)